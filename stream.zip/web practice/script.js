function login() {
  const username = document.getElementById("usernameInput").value.trim();
  if (!username) {
    alert("Please enter your name.");
    return;
  }
  localStorage.setItem("krUser", username);
  showMain(username);
}

function logout() {
  localStorage.removeItem("krUser");
  location.reload();
}

function showMain(username) {
  document.getElementById("loginContainer").style.display = "none";
  document.getElementById("mainContainer").style.display = "block";
  document.getElementById("usernameDisplay").textContent = username;
}

function changeUsername() {
  const newName = prompt("Enter your new username:");
  if (newName && newName.trim()) {
    localStorage.setItem("krUser", newName.trim());
    document.getElementById("usernameDisplay").textContent = newName.trim();
  }
}

window.addEventListener("load", () => {
  const savedUser = localStorage.getItem("krUser");
  if (savedUser) {
    showMain(savedUser);
  } else {
    document.getElementById("loginContainer").style.display = "block";
    document.getElementById("mainContainer").style.display = "none";
  }

  // Load saved avatar
  const savedAvatar = localStorage.getItem("avatar");
  if (savedAvatar) {
    document.getElementById("avatar").src = savedAvatar;
  }

  // Load saved theme
  const savedTheme = localStorage.getItem("theme");
  if (savedTheme === "light") {
    document.body.classList.add("light-mode");
    document.getElementById("theme-toggle").innerText = "🌙 Dark Mode";
  }
});

// Hamburger menu toggle
document.getElementById("menu-toggle").addEventListener("click", () => {
  document.getElementById("nav-links").classList.toggle("show");
});

// Avatar upload
document.getElementById("avatar-upload").addEventListener("change", function () {
  const file = this.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = function (e) {
      const avatarSrc = e.target.result;
      document.getElementById("avatar").src = avatarSrc;
      localStorage.setItem("avatar", avatarSrc);
    };
    reader.readAsDataURL(file);
  }
});

// Theme toggle
document.getElementById("theme-toggle").addEventListener("click", function () {
  document.body.classList.toggle("light-mode");

  if (document.body.classList.contains("light-mode")) {
    this.innerText = "🌙 Dark Mode";
    localStorage.setItem("theme", "light");
  } else {
    this.innerText = "🌞 Light Mode";
    localStorage.setItem("theme", "dark");
  }
});
// ----- NOW PLAYING UI & CONTROLS -----

const nowPlayingBar = document.getElementById("nowPlayingBar");
const nowPlayingTitle = document.getElementById("nowPlayingTitle");
const playPauseBtn = document.getElementById("playPauseBtn");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const progressBar = document.getElementById("progressBar");

let playlist = []; // Will hold media objects {type:"audio"/"video", title:"", element:HTMLElement}
let currentIndex = -1;
let isPlaying = false;
let progressInterval = null;

// Initialize playlist from localStorage if any
function loadPlaylist() {
  const saved = localStorage.getItem("krPlaylist");
  if (saved) {
    playlist = JSON.parse(saved);
    renderPlaylist();
  }
}

// Save playlist to localStorage
function savePlaylist() {
  localStorage.setItem("krPlaylist", JSON.stringify(playlist));
}

// Render playlist items to UL
function renderPlaylist() {
  const list = document.getElementById("playlist");
  list.innerHTML = "";
  playlist.forEach((item, idx) => {
    const li = document.createElement("li");
    li.style.padding = "5px";
    li.style.cursor = "pointer";
    li.textContent = item.title + " (" + item.type + ")";
    if (idx === currentIndex) li.style.fontWeight = "bold";
    li.onclick = () => playFromIndex(idx);
    list.appendChild(li);
  });
}

// Play a media by index in playlist
function playFromIndex(idx) {
  if (idx < 0 || idx >= playlist.length) return;
  // Pause current
  if (currentIndex !== -1 && playlist[currentIndex]) {
    playlist[currentIndex].element.pause();
    playlist[currentIndex].element.currentTime = 0;
  }

  currentIndex = idx;
  const media = playlist[currentIndex];
  nowPlayingTitle.textContent = "Now Playing: " + media.title;
  nowPlayingBar.style.display = "flex";

  // Play media element
  media.element.play();
  isPlaying = true;
  playPauseBtn.textContent = "⏸️";

  setupProgress(media.element);
  renderPlaylist();
}

// Setup progress bar updates
function setupProgress(mediaEl) {
  clearInterval(progressInterval);
  progressBar.value = 0;
  progressBar.max = mediaEl.duration || 100;

  progressInterval = setInterval(() => {
    if (!mediaEl.paused && !mediaEl.ended) {
      progressBar.value = mediaEl.currentTime;
      progressBar.max = mediaEl.duration;
    } else if (mediaEl.ended) {
      nextTrack();
    }
  }, 500);
}

// Play/pause toggle
playPauseBtn.onclick = () => {
  if (currentIndex === -1) return;
  const media = playlist[currentIndex];
  if (isPlaying) {
    media.element.pause();
    playPauseBtn.textContent = "▶️";
  } else {
    media.element.play();
    playPauseBtn.textContent = "⏸️";
  }
  isPlaying = !isPlaying;
};

// Next track
nextBtn.onclick = () => {
  nextTrack();
};

function nextTrack() {
  if (playlist.length === 0) return;
  let nextIndex = currentIndex + 1;
  if (nextIndex >= playlist.length) nextIndex = 0;
  playFromIndex(nextIndex);
}

// Previous track
prevBtn.onclick = () => {
  if (playlist.length === 0) return;
  let prevIndex = currentIndex - 1;
  if (prevIndex < 0) prevIndex = playlist.length - 1;
  playFromIndex(prevIndex);
};

// ----- ADD TO PLAYLIST BUTTON LOGIC -----
document.getElementById("addToPlaylistBtn").onclick = () => {
  const input = document.getElementById("playlistInput");
  const titleToAdd = input.value.trim();
  if (!titleToAdd) {
    alert("Please enter a song or video title to add.");
    return;
  }

  // Search for matching media cards (audio or video)
  let found = false;

  // Search music
  document.querySelectorAll("#music .media-card").forEach((card) => {
    const h3 = card.querySelector("h3");
    if (h3 && h3.textContent.toLowerCase() === titleToAdd.toLowerCase()) {
      // Get audio element
      const audio = card.querySelector("audio");
      if (audio) {
        playlist.push({ type: "audio", title: h3.textContent, element: audio });
        found = true;
      }
    }
  });

  // Search videos
  document.querySelectorAll("#videos .media-card").forEach((card) => {
    const p = card.querySelector("p");
    if (p && p.textContent.toLowerCase() === titleToAdd.toLowerCase()) {
      // Get video element
      const video = card.querySelector("video");
      if (video) {
        playlist.push({ type: "video", title: p.textContent, element: video });
        found = true;
      }
    }
  });

  if (!found) {
    alert("Could not find media with that exact title. Please check spelling.");
    return;
  }

  savePlaylist();
  renderPlaylist();
  input.value = "";
};

// ----- USER PROFILE: SAVE & LOAD ABOUT ME + FAVORITES -----

const aboutMeTextarea = document.getElementById("aboutMe");
const saveProfileBtn = document.getElementById("saveProfileBtn");
const favoritesList = document.getElementById("favoritesList");

// Load profile on page load
window.addEventListener("load", () => {
  // Load about me
  const aboutMe = localStorage.getItem("krAboutMe");
  if (aboutMe) aboutMeTextarea.value = aboutMe;

  // Load favorites
  const savedFavs = localStorage.getItem("krFavorites");
  if (savedFavs) {
    const favs = JSON.parse(savedFavs);
    renderFavorites(favs);
  }
});

// Save profile info
saveProfileBtn.onclick = () => {
  const aboutMeText = aboutMeTextarea.value.trim();
  localStorage.setItem("krAboutMe", aboutMeText);
  alert("Profile saved!");
};

// Add favorite on playlist item click (toggle favorite)
function toggleFavorite(title) {
  const savedFavs = localStorage.getItem("krFavorites");
  let favs = savedFavs ? JSON.parse(savedFavs) : [];

  if (favs.includes(title)) {
    // Remove favorite
    favs = favs.filter((t) => t !== title);
  } else {
    favs.push(title);
  }
  localStorage.setItem("krFavorites", JSON.stringify(favs));
  renderFavorites(favs);
  renderPlaylist(); // to update playlist item bold or not
}

// Render favorites list
function renderFavorites(favs) {
  favoritesList.innerHTML = "";
  favs.forEach((title) => {
    const li = document.createElement("li");
    li.style.cursor = "pointer";
    li.textContent = title + " ⭐";
    li.onclick = () => {
      // Play favorite media if found in playlist
      const idx = playlist.findIndex((item) => item.title === title);
      if (idx !== -1) playFromIndex(idx);
    };
    favoritesList.appendChild(li);
  });
}

// Update playlist render to show favorite star
function renderPlaylist() {
  const list = document.getElementById("playlist");
  list.innerHTML = "";
  const savedFavs = localStorage.getItem("krFavorites");
  const favs = savedFavs ? JSON.parse(savedFavs) : [];

  playlist.forEach((item, idx) => {
    const li = document.createElement("li");
    li.style.padding = "5px";
    li.style.cursor = "pointer";
    li.textContent = item.title + " (" + item.type + ")";
    if (idx === currentIndex) li.style.fontWeight = "bold";
    if (favs.includes(item.title)) li.textContent += " ⭐";
    li.onclick = () => playFromIndex(idx);
    li.ondblclick = () => toggleFavorite(item.title);
    list.appendChild(li);
  });
}

// Update playlist render call after loading playlist and favorites
window.addEventListener("load", () => {
  loadPlaylist();
});
